﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Kalaha
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btn7 = New System.Windows.Forms.Button()
        Me.btn14 = New System.Windows.Forms.Button()
        Me.btn8 = New System.Windows.Forms.Button()
        Me.btn9 = New System.Windows.Forms.Button()
        Me.btn10 = New System.Windows.Forms.Button()
        Me.btn11 = New System.Windows.Forms.Button()
        Me.btn12 = New System.Windows.Forms.Button()
        Me.btn13 = New System.Windows.Forms.Button()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.btn4 = New System.Windows.Forms.Button()
        Me.btn5 = New System.Windows.Forms.Button()
        Me.btn6 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnPlay = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn7
        '
        Me.btn7.Location = New System.Drawing.Point(408, 72)
        Me.btn7.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btn7.Name = "btn7"
        Me.btn7.Size = New System.Drawing.Size(47, 32)
        Me.btn7.TabIndex = 27
        Me.btn7.UseVisualStyleBackColor = True
        '
        'btn14
        '
        Me.btn14.Location = New System.Drawing.Point(27, 72)
        Me.btn14.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btn14.Name = "btn14"
        Me.btn14.Size = New System.Drawing.Size(47, 32)
        Me.btn14.TabIndex = 26
        Me.btn14.UseVisualStyleBackColor = True
        '
        'btn8
        '
        Me.btn8.Location = New System.Drawing.Point(332, 96)
        Me.btn8.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btn8.Name = "btn8"
        Me.btn8.Size = New System.Drawing.Size(47, 32)
        Me.btn8.TabIndex = 25
        Me.btn8.UseVisualStyleBackColor = True
        '
        'btn9
        '
        Me.btn9.Location = New System.Drawing.Point(287, 96)
        Me.btn9.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btn9.Name = "btn9"
        Me.btn9.Size = New System.Drawing.Size(47, 32)
        Me.btn9.TabIndex = 24
        Me.btn9.UseVisualStyleBackColor = True
        '
        'btn10
        '
        Me.btn10.Location = New System.Drawing.Point(241, 96)
        Me.btn10.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btn10.Name = "btn10"
        Me.btn10.Size = New System.Drawing.Size(47, 32)
        Me.btn10.TabIndex = 23
        Me.btn10.UseVisualStyleBackColor = True
        '
        'btn11
        '
        Me.btn11.Location = New System.Drawing.Point(196, 96)
        Me.btn11.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btn11.Name = "btn11"
        Me.btn11.Size = New System.Drawing.Size(47, 32)
        Me.btn11.TabIndex = 22
        Me.btn11.UseVisualStyleBackColor = True
        '
        'btn12
        '
        Me.btn12.Location = New System.Drawing.Point(151, 96)
        Me.btn12.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btn12.Name = "btn12"
        Me.btn12.Size = New System.Drawing.Size(47, 32)
        Me.btn12.TabIndex = 21
        Me.btn12.UseVisualStyleBackColor = True
        '
        'btn13
        '
        Me.btn13.Location = New System.Drawing.Point(105, 96)
        Me.btn13.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btn13.Name = "btn13"
        Me.btn13.Size = New System.Drawing.Size(47, 32)
        Me.btn13.TabIndex = 20
        Me.btn13.UseVisualStyleBackColor = True
        '
        'btn1
        '
        Me.btn1.Location = New System.Drawing.Point(105, 46)
        Me.btn1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(47, 32)
        Me.btn1.TabIndex = 19
        Me.btn1.UseVisualStyleBackColor = True
        '
        'btn2
        '
        Me.btn2.Location = New System.Drawing.Point(151, 46)
        Me.btn2.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(47, 32)
        Me.btn2.TabIndex = 18
        Me.btn2.UseVisualStyleBackColor = True
        '
        'btn3
        '
        Me.btn3.Location = New System.Drawing.Point(196, 46)
        Me.btn3.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(47, 32)
        Me.btn3.TabIndex = 17
        Me.btn3.UseVisualStyleBackColor = True
        '
        'btn4
        '
        Me.btn4.Location = New System.Drawing.Point(241, 46)
        Me.btn4.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btn4.Name = "btn4"
        Me.btn4.Size = New System.Drawing.Size(47, 32)
        Me.btn4.TabIndex = 16
        Me.btn4.UseVisualStyleBackColor = True
        '
        'btn5
        '
        Me.btn5.Location = New System.Drawing.Point(287, 46)
        Me.btn5.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btn5.Name = "btn5"
        Me.btn5.Size = New System.Drawing.Size(47, 32)
        Me.btn5.TabIndex = 15
        Me.btn5.UseVisualStyleBackColor = True
        '
        'btn6
        '
        Me.btn6.Location = New System.Drawing.Point(332, 46)
        Me.btn6.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btn6.Name = "btn6"
        Me.btn6.Size = New System.Drawing.Size(47, 32)
        Me.btn6.TabIndex = 14
        Me.btn6.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(23, 127)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 15)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "Joueur 2"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(401, 45)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 15)
        Me.Label2.TabIndex = 29
        Me.Label2.Text = "Joueur 1"
        '
        'btnPlay
        '
        Me.btnPlay.Location = New System.Drawing.Point(183, 159)
        Me.btnPlay.Name = "btnPlay"
        Me.btnPlay.Size = New System.Drawing.Size(84, 30)
        Me.btnPlay.TabIndex = 30
        Me.btnPlay.Text = "Play"
        Me.btnPlay.UseVisualStyleBackColor = True
        '
        'Kalaha
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(499, 214)
        Me.Controls.Add(Me.btnPlay)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btn7)
        Me.Controls.Add(Me.btn14)
        Me.Controls.Add(Me.btn8)
        Me.Controls.Add(Me.btn9)
        Me.Controls.Add(Me.btn10)
        Me.Controls.Add(Me.btn11)
        Me.Controls.Add(Me.btn12)
        Me.Controls.Add(Me.btn13)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.btn4)
        Me.Controls.Add(Me.btn5)
        Me.Controls.Add(Me.btn6)
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "Kalaha"
        Me.Text = "Jeu du Kalaha"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn7 As Button
    Friend WithEvents btn14 As Button
    Friend WithEvents btn8 As Button
    Friend WithEvents btn9 As Button
    Friend WithEvents btn10 As Button
    Friend WithEvents btn11 As Button
    Friend WithEvents btn12 As Button
    Friend WithEvents btn13 As Button
    Friend WithEvents btn1 As Button
    Friend WithEvents btn2 As Button
    Friend WithEvents btn3 As Button
    Friend WithEvents btn4 As Button
    Friend WithEvents btn5 As Button
    Friend WithEvents btn6 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnPlay As Button
End Class
